%% 1. การตั้งค่า (Configuration)
clc; clear; close all;

FILES = {
    '1by4Mode_(100_f).mat',   100,   'Acc = 100 Hz/s';
    '1by4Mode_(1000_f).mat',  1000,  'Acc = 1,000 Hz/s';
    '1by4Mode_(5000_f).mat',  5000,  'Acc = 5,000 Hz/s'
};

COLORS = {[0 0.6 0], [0 0 1], [1 0 0]}; % เขียว, น้ำเงิน, แดง

fprintf('---------------------------------------------------\n');
fprintf('Diagnosing & Plotting Stepper Motor Acceleration...\n');

%% 2. เตรียมกราฟ
fig1 = figure('Name', 'Speed vs Time', 'Color', 'w', 'Position', [50, 50, 600, 500]); hold on; grid on;
xlabel('Time (s)'); ylabel('Speed (rad/s)'); title('Speed vs Time');

fig2 = figure('Name', 'Speed vs Frequency', 'Color', 'w', 'Position', [700, 50, 600, 500]); hold on; grid on;
xlabel('Frequency (Hz)'); ylabel('Speed (rad/s)'); title('Speed vs Frequency');

%% 3. วนลูปประมวลผล
for i = 1:size(FILES, 1)
    filename = FILES{i, 1};
    acc_val  = FILES{i, 2};
    legend_name = FILES{i, 3};
    
    fprintf('\n[%d] Processing %s ... ', i, filename);
    
    try
        if ~isfile(filename), fprintf('File not found!\n'); continue; end
        
        raw = load(filename);
        ds = extract_dataset(raw);
        
        % --- หาสัญญาณ Speed ---
        sig_spd = find_signal_smart(ds, {'Speed', 'Velocity', 'rad', 'rpm'}, 'Speed');
        t = sig_spd.Values.Time(:);
        spd = sig_spd.Values.Data(:);
        
        % --- หาสัญญาณ Freq (หรือคำนวณเอา) ---
        try
            sig_freq = find_signal_smart(ds, {'Freq', 'Hz', 'Input'}, 'Freq');
            freq = sig_freq.Values.Data(:);
            
            % เช็คความยาว (ตัดให้เท่ากัน)
            len = min(length(spd), length(freq));
            t = t(1:len); spd = spd(1:len); freq = freq(1:len);
            fprintf('Found Freq Signal. ');
        catch
            % ถ้าหาไม่เจอ -> คำนวณจาก เวลา * ความเร่ง
            freq = t * acc_val;
            fprintf('Calc Freq from Time. ');
        end
        
        fprintf('Points: %d, Max Spd: %.2f, Max Freq: %.0f\n', length(spd), max(spd), max(freq));
        
        % --- Plot 1: Speed vs Time ---
        figure(fig1);
        plot(t, spd, 'LineWidth', 2, 'Color', COLORS{i}, 'DisplayName', legend_name);
        
        % --- Plot 2: Speed vs Frequency ---
        figure(fig2);
        plot(freq, spd, 'LineWidth', 2, 'Color', COLORS{i}, 'DisplayName', legend_name);
        
        % หาจุด Stall (Max Speed)
        [max_s, idx] = max(spd);
        stall_f = freq(idx);
        plot(stall_f, max_s, 'x', 'Color', COLORS{i}, 'MarkerSize', 10, 'LineWidth', 2, 'HandleVisibility','off');
        
    catch ME
        fprintf('Error: %s\n', ME.message);
    end
end

%% 3. ตกแต่งกราฟ (Final Touch - White Background)

% --- ตกแต่งรูปที่ 1 (Speed vs Time) ---
figure(fig1); 
set(gcf, 'Color', 'w');       % พื้นหลังหน้าต่างโปรแกรม -> ขาว
set(gca, 'Color', 'w');       % พื้นหลังในกราฟ -> ขาว
set(gca, 'XColor', 'k', 'YColor', 'k'); % แกนสีดำ

title('Speed vs Time', 'FontSize', 16, 'Color', 'k');
xlabel('Time (s)', 'FontSize', 14, 'FontWeight', 'bold', 'Color', 'k');
ylabel('Speed (rad/s)', 'FontSize', 14, 'FontWeight', 'bold', 'Color', 'k');
legend('Location', 'best', 'FontSize', 12, 'TextColor', 'k', 'Color', 'w'); % พื้นหลัง Legend ขาว

grid on;
set(gca, 'GridColor', [0.1 0.1 0.1]); % เส้นตารางสีเทาเข้ม
set(gca, 'GridAlpha', 0.4);           % ความเข้มเส้นตาราง
axis tight; 

% --- ตกแต่งรูปที่ 2 (Speed vs Frequency) ---
figure(fig2); 
set(gcf, 'Color', 'w');       % พื้นหลังหน้าต่างโปรแกรม -> ขาว
set(gca, 'Color', 'w');       % พื้นหลังในกราฟ -> ขาว
set(gca, 'XColor', 'k', 'YColor', 'k'); % แกนสีดำ

title('Speed vs Frequency', 'FontSize', 16, 'Color', 'k');
xlabel('Frequency (Hz)', 'FontSize', 14, 'FontWeight', 'bold', 'Color', 'k');
ylabel('Speed (rad/s)', 'FontSize', 14, 'FontWeight', 'bold', 'Color', 'k');
legend('Location', 'best', 'FontSize', 12, 'TextColor', 'k', 'Color', 'w');

grid on;
set(gca, 'GridColor', [0.1 0.1 0.1]); % เส้นตารางสีเทาเข้ม
set(gca, 'GridAlpha', 0.4);
axis tight; 

fprintf('\nเสร็จสิ้น! บังคับพื้นหลังขาว + เส้นตารางชัดเจนแล้วครับ\n');

%% Helper
function ds = extract_dataset(loaded_struct)
    names = fieldnames(loaded_struct);
    ds = loaded_struct.(names{1});
end
function sig = find_signal_smart(ds, keywords, type_name)
    all_names = ds.getElementNames();
    for i = 1:length(all_names)
        for k = 1:length(keywords)
            if contains(all_names{i}, keywords{k}, 'IgnoreCase', true)
                sig = ds.getElement(i);
                return;
            end
        end
    end
    error('Not found');
end