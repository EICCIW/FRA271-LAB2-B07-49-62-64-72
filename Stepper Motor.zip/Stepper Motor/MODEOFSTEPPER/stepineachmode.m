%% 1. การตั้งค่า (Configuration)
clc; clear; close all;

FILES = {
    '100Hz(FullSterp).mat',    'Full Step';
    '1000Hz(1by2Step).mat',     '1/2 Step';
    '500HZ(1by4Step).mat',     '1/4 Step';
    '500Hz(8microStep).mat',   '1/8 Microstep';
    '1000Hz(16microStep)1.mat', '1/16 Microstep';
    '1000Hz(32microStep).mat', '1/32 Microstep'
};

COLORS = lines(6); 

fprintf('---------------------------------------------------\n');
fprintf('Generating 7 Graphs (1 Combined + 6 Separate)...\n');

%% 2. เตรียมกราฟรวม (Figure 1)
fig_comb = figure('Name', 'All Modes Comparison', 'Color', 'w', 'Position', [50, 50, 1000, 600]);
hold on; grid on; box on;

% ตกแต่งกราฟรวม
set(gca, 'Color', 'w');       
set(gca, 'XColor', 'k', 'YColor', 'k'); 
title('Stepper Motor Speed vs Frequency (All Modes)', 'FontSize', 16, 'Color', 'k');
xlabel('Input Frequency (Hz)', 'FontSize', 14, 'FontWeight', 'bold', 'Color', 'k');
ylabel('Motor Speed (rad/s)', 'FontSize', 14, 'FontWeight', 'bold', 'Color', 'k');

%% 3. วนลูปทำทีละไฟล์
for i = 1:size(FILES, 1)
    filename = FILES{i, 1};
    legend_name = FILES{i, 2};
    
    fprintf('[%d] Processing %s... ', i, legend_name);
    
    try
        if ~isfile(filename), fprintf('(ไม่พบไฟล์)\n'); continue; end
        
        raw = load(filename);
        ds = extract_dataset(raw);
        
        sig_freq = find_signal_smart(ds, {'Freq', 'Hz', 'Pulse', 'Step', 'Input', 'Ramp'}, 'Frequency');
        sig_spd = find_signal_smart(ds, {'Speed', 'Velocity', 'rad', 'rpm', 'W'}, 'Speed');
        
        % Flatten Data
        x_freq = sig_freq.Values.Data(:);
        y_spd  = sig_spd.Values.Data(:);
        
        len = min(length(x_freq), length(y_spd));
        x_freq = x_freq(1:len);
        y_spd  = y_spd(1:len);
        
        % --- 3.1 พล็อตลงกราฟรวม ---
        figure(fig_comb);
        plot(x_freq, y_spd, '-', 'Color', COLORS(i,:), 'LineWidth', 2, 'DisplayName', legend_name);
        
        % --- 3.2 พล็อตแยกกราฟเดี่ยว (สร้างหน้าต่างใหม่) ---
        fig_single = figure('Name', ['Mode: ' legend_name], 'Color', 'w');
        plot(x_freq, y_spd, '-', 'Color', COLORS(i,:), 'LineWidth', 2);
        
        % ตกแต่งกราฟเดี่ยว (ธีมขาว-ดำ)
        set(gca, 'Color', 'w');
        set(gca, 'XColor', 'k', 'YColor', 'k');
        
        title(sprintf('Mode: %s (Max Freq: %.0f Hz)', legend_name, max(x_freq)), ...
              'FontSize', 14, 'Color', 'k');
        xlabel('Input Frequency (Hz)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
        ylabel('Motor Speed (rad/s)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
        
        grid on; box on;
        set(gca, 'GridColor', [0.2 0.2 0.2]); 
        set(gca, 'GridAlpha', 0.4);
        
        axis tight;
        ylim([0, max(y_spd)*1.2]); 
        
        fprintf('Done.\n');
        
    catch ME
        fprintf('\n   ERROR: %s\n', ME.message);
    end
end

% ใส่ Legend ให้กราฟรวม
figure(fig_comb);
legend('Location', 'best', 'FontSize', 12, 'TextColor', 'k', 'Color', 'w');
% ตกแต่ง Grid กราฟรวม
set(gca, 'GridColor', [0.2 0.2 0.2]); 
set(gca, 'GridAlpha', 0.4);

fprintf('---------------------------------------------------\n');
fprintf('เสร็จสิ้น! กราฟทั้ง 7 รูป พร้อมใช้งานครับ\n');

%% --- Helper Functions ---
function ds = extract_dataset(loaded_struct)
    names = fieldnames(loaded_struct);
    ds = loaded_struct.(names{1});
end

function sig = find_signal_smart(ds, keywords, type_name)
    all_names = ds.getElementNames();
    for i = 1:length(all_names)
        for k = 1:length(keywords)
            if contains(all_names{i}, keywords{k}, 'IgnoreCase', true)
                sig = ds.getElement(i);
                return;
            end
        end
    end
    if strcmp(type_name, 'Frequency'), sig = ds.getElement(1);
    else, sig = ds.getElement(2); end
end