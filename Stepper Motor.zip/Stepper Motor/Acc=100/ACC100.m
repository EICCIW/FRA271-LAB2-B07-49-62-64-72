%% 1. การตั้งค่า (Configuration)
clc; clear; close all;

% รายชื่อไฟล์ 3 ครั้ง (ชื่อไฟล์ตามที่คุณส่งมาเป๊ะๆ)
FILES = {
    '1by4Mode_(100_f)_2.mat',        'Run 1';
    '1by4Mode_(100_f)_2(ครั้ง2).mat', 'Run 2';
    '1by4Mode_(100_f)_2(ครั้ง3).mat', 'Run 3'
};

% สีเส้น
COLORS = {
    [0 0.4470 0.7410], % น้ำเงิน
    [0.8500 0.3250 0.0980], % ส้มแดง
    [0.4660 0.6740 0.1880]  % เขียว
};

LINE_STYLES = {'-', '--', '-.'}; 

fprintf('---------------------------------------------------\n');
fprintf('Plotting Repeatability Test (Acc = 100 Hz/s)...\n');

%% 2. สร้างกราฟรวม
figure('Name', 'Repeatability Test', 'Color', 'w', 'Position', [100, 100, 1000, 600]);
hold on; grid on; box on;

% บังคับธีมขาว-ดำ
set(gca, 'Color', 'w');
set(gca, 'XColor', 'k', 'YColor', 'k');

max_freq_global = 0;
max_speed_global = 0;

for i = 1:size(FILES, 1)
    filename = FILES{i, 1};
    legend_name = FILES{i, 2};
    
    fprintf('[%d] Loading %s ... ', i, filename);
    
    try
        if ~isfile(filename), fprintf('(ไม่พบไฟล์)\n'); continue; end
        
        raw = load(filename);
        ds = extract_dataset(raw); 
        
        % --- หาสัญญาณ ---
        sig_freq = find_signal_smart(ds, {'Freq', 'Hz', 'Input'}, 'Freq');
        sig_spd = find_signal_smart(ds, {'Speed', 'Velocity', 'rad', 'rpm'}, 'Speed');
        
        % ดึงข้อมูล (Flatten ให้เป็นเส้นตรง)
        x_freq = sig_freq.Values.Data(:);
        y_spd  = sig_spd.Values.Data(:);
        
        % ตัดให้เท่ากัน
        len = min(length(x_freq), length(y_spd));
        x_freq = x_freq(1:len);
        y_spd = y_spd(1:len);
        
        % --- หาจุด Stall (จุดที่ความเร็วสูงสุด ก่อนจะตกลงมา) ---
        [max_spd, idx_max] = max(y_spd);
        stall_freq = x_freq(idx_max);
        
        % เก็บค่า Max รวมไว้จัดแกน
        max_freq_global = max(max_freq_global, max(x_freq));
        max_speed_global = max(max_speed_global, max(y_spd));
        
        % --- พล็อตเส้น ---
        plot(x_freq, y_spd, 'LineStyle', LINE_STYLES{i}, 'Color', COLORS{i}, ...
             'LineWidth', 2, 'DisplayName', sprintf('%s (Stall @ %.0f Hz)', legend_name, stall_freq));
         
        % มาร์คจุด Stall
        plot(stall_freq, max_spd, 'x', 'Color', 'k', 'MarkerSize', 12, 'LineWidth', 2, 'HandleVisibility', 'off');
        
        fprintf('Done. Stall found at %.0f Hz\n', stall_freq);
        
    catch ME
        fprintf('Error: %s\n', ME.message);
    end
end

%% 3. ตกแต่งกราฟ
title('Repeatability Test: Stepper Motor Acceleration (100 Hz/s)', 'FontSize', 16, 'Color', 'k');
xlabel('Input Frequency (Hz)', 'FontSize', 14, 'FontWeight', 'bold', 'Color', 'k');
ylabel('Motor Speed (rad/s)', 'FontSize', 14, 'FontWeight', 'bold', 'Color', 'k');

% --- [แก้ไข] ทำให้พื้นหลัง Legend เป็นสีขาว ---
legend('Location', 'northwest', 'FontSize', 12, ...
       'TextColor', 'k', ...
       'Color', 'w', ...       % พื้นหลังขาว
       'EdgeColor', 'k');      % ขอบสีดำ

% ตั้งแกนให้สวยงาม
if max_freq_global > 0
    xlim([0, max_freq_global]);
    ylim([0, max_speed_global * 1.2]);
end

grid on;
set(gca, 'GridColor', [0.2 0.2 0.2]); 
set(gca, 'GridAlpha', 0.4);

fprintf('---------------------------------------------------\n');
fprintf('เสร็จสิ้น! เช็คกราฟได้เลยครับ (Stall ควรจะอยู่แถวๆ 21,000 Hz ตามข้อมูล)\n');

%% --- Helper Functions (ห้ามลบ! ต้องอยู่ท้ายสุด) ---
function ds = extract_dataset(loaded_struct)
    % ฟังก์ชันแกะกล่องข้อมูล (รองรับทั้งแบบ struct และ object)
    names = fieldnames(loaded_struct);
    ds = loaded_struct.(names{1});
end

function sig = find_signal_smart(ds, keywords, type_name)
    % ฟังก์ชันค้นหาสัญญาณแบบฉลาด
    all_names = ds.getElementNames();
    for i = 1:length(all_names)
        for k = 1:length(keywords)
            if contains(all_names{i}, keywords{k}, 'IgnoreCase', true)
                sig = ds.getElement(i);
                return;
            end
        end
    end
    % Fallback ถ้าหาไม่เจอ
    if strcmp(type_name, 'Freq'), sig = ds.getElement(1); else, sig = ds.getElement(2); end
end