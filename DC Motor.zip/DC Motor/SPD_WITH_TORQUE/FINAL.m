clc; clear; close all;

FILE_NOLOAD = 'No_load.mat';
FILE_STALL  = 'Stall.mat';

RADIUS = 0.11;          % รัศมี (เมตร)
LOAD_GAIN = 620.5;      % Gain (ถ้าค่า Load Cell เป็นค่าดิบ)

% ระดับแรงดันที่ต้องการพล็อต
VOLTAGE_RATIOS = [0.25, 0.50, 0.75, 1.00]; 
VOLTAGE_NAMES  = {'3V (25%)', '6V (50%)', '9V (75%)', '12V (100%)'};
LINE_COLORS    = {'#D95319', '#EDB120', '#77AC30', '#81D4FA'}; 

fprintf('---------------------------------------------------\n');
fprintf('Generating Speed vs Torque Curves (Scaling Method)...\n');

%% 2. หาค่าสูงสุดจากไฟล์ NO LOAD (Max Speed @ 12V)
try
    fprintf('[1] Loading %s ... \n', FILE_NOLOAD);
    raw_nl = load(FILE_NOLOAD);
    ds_nl = extract_dataset(raw_nl);
    
    % หาสัญญาณ Speed
    sig_spd_nl = find_signal_smart(ds_nl, {'Speed', 'Velocity', 'rad', 'rpm', 'Angular'}, 'Speed');
    
    % **ใช้ค่าสูงสุด (Max)** เป็นตัวแทนของ 100% (12V)
    MAX_SPEED_REAL = max(sig_spd_nl.Values.Data);
    
    fprintf('    -> พบสัญญาณ Speed ชื่อ: %s\n', sig_spd_nl.Name);
    fprintf('    -> Max Speed (ที่ 12V): %.2f rad/s\n', MAX_SPEED_REAL);
    
catch ME
    fprintf('\nERROR No_load: %s\n', ME.message);
    return;
end

%% 3. หาค่าสูงสุดจากไฟล์ STALL (Max Torque @ 12V)
try
    fprintf('\n[2] Loading %s ... \n', FILE_STALL);
    raw_st = load(FILE_STALL);
    ds_st = extract_dataset(raw_st);
    
    % หาสัญญาณ Torque หรือ Load Cell
    try
        sig_trq_st = find_signal_smart(ds_st, {'Torque', 'Nm'}, 'Torque');
        data_trq = sig_trq_st.Values.Data;
        fprintf('    -> พบสัญญาณ Torque โดยตรง\n');
    catch
        sig_load_st = find_signal_smart(ds_st, {'Load', 'Cell', 'Force', 'PA0', 'Weight'}, 'Load Cell');
        fprintf('    -> พบสัญญาณ Load Cell ชื่อ: %s\n', sig_load_st.Name);
        
        % คำนวณ Torque
        raw_data = sig_load_st.Values.Data;
        if mean(raw_data) < 100 
             raw_data = raw_data * LOAD_GAIN; % คูณ Gain ถ้าค่าดูน้อย (ADC)
        end
        data_trq = (raw_data * 0.00981) * RADIUS;
    end
    
    % **ใช้ค่าสูงสุด (Max)** เป็นตัวแทนของ 100% (12V)
    MAX_TORQUE_REAL = max(data_trq);
    fprintf('    -> Max Torque (ที่ 12V): %.4f Nm\n', MAX_TORQUE_REAL);

catch ME
    fprintf('\nERROR Stall: %s\n', ME.message);
    return;
end

%% 4. สร้างกราฟ (Scaling)
fprintf('\n[3] Plotting Graphs...\n');
figure('Name', 'Speed-Torque Characteristics', 'Color', 'w', 'Position', [100, 100, 800, 600]);
hold on; grid on;

h_lines = [];

for i = 1:length(VOLTAGE_RATIOS)
    ratio = VOLTAGE_RATIOS(i);
    
    % คำนวณจุดตัดแกนตามอัตราส่วนแรงดัน (Linear Scaling)
    % V ลดลง -> Speed ลดลงตามสัดส่วน
    % V ลดลง -> Stall Torque ลดลงตามสัดส่วน
    current_no_load_spd = MAX_SPEED_REAL * ratio;
    current_stall_trq   = MAX_TORQUE_REAL * ratio;
    
    % พล็อตเส้นเชื่อม (0, Speed) -> (Torque, 0)
    h = plot([0, current_stall_trq], [current_no_load_spd, 0], 'o-', ...
        'LineWidth', 2, 'Color', LINE_COLORS{i}, 'MarkerFaceColor', 'w');
    h_lines = [h_lines, h];
    
    % แสดงตัวเลขกำกับ
    text(0, current_no_load_spd, sprintf(' %.1f', current_no_load_spd), ...
        'Color', LINE_COLORS{i}, 'VerticalAlignment', 'bottom', 'FontWeight', 'bold');
end

title('DC Motor Speed-Torque Characteristics', 'FontSize', 16);
xlabel('Torque (N-m)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Speed (rad/s)', 'FontSize', 12, 'FontWeight', 'bold');
legend(h_lines, VOLTAGE_NAMES, 'Location', 'northeast', 'FontSize', 11);

% จัดแกน
xlim([0, MAX_TORQUE_REAL*1.2]);
ylim([0, MAX_SPEED_REAL*1.2]);

fprintf('เสร็จสิ้น! กราฟแสดงผลครบถ้วนครับ\n');

%% --- Helper Functions ---
function ds = extract_dataset(loaded_struct)
    names = fieldnames(loaded_struct);
    ds = loaded_struct.(names{1});
end

function sig = find_signal_smart(ds, keywords, type_name)
    all_names = ds.getElementNames();
    for i = 1:length(all_names)
        for k = 1:length(keywords)
            if contains(all_names{i}, keywords{k}, 'IgnoreCase', true)
                sig = ds.getElement(i);
                return;
            end
        end
    end
    error('ไม่พบสัญญาณ %s (ลองเช็คชื่อในไฟล์ .mat)', type_name);
end


