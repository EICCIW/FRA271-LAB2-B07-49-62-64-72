%% 1. การตั้งค่า (Configuration)
clc; clear; close all;

FILENAME = 'lock(0-(-100)).mat';
PWM_MAX_RAW = 65535; 

% ลำดับเป้าหมาย (0 -> -100 -> 0)
TARGET_SEQUENCE = [0, -10, -20, -30, -40, -50, -60, -70, -80, -90, -100, ...
                   -90, -80, -70, -60, -50, -40, -30, -20, -10, 0];

TOLERANCE = 3; 

fprintf('---------------------------------------------------\n');
fprintf('Generating Unfolded Hysteresis (Forcing Zero at 0%%)...\n');

%% 2. โหลดและดึงข้อมูล
try
    if ~isfile(FILENAME), error('หาไฟล์ %s ไม่เจอ!', FILENAME); end
    
    raw = load(FILENAME);
    ds = extract_dataset(raw);
    
    sig_pwm = find_signal_smart(ds, {'PWM', 'Ramp', 'Gain'}, 'PWM');
    sig_spd = find_signal_smart(ds, {'Speed', 'Velocity', 'rad', 'rpm', 'W'}, 'Speed');
    
    d_pwm = sig_pwm.Values.Data;
    d_spd = sig_spd.Values.Data;
    
    if length(d_pwm) ~= length(d_spd)
        d_pwm = interp1(sig_pwm.Values.Time, double(d_pwm), sig_spd.Values.Time, 'previous', 'extrap');
    end
    
    pwm_pct = (double(d_pwm) / PWM_MAX_RAW) * 100;
    
    % Auto-Invert
    if contains(FILENAME, '-') && min(pwm_pct) >= 0
         pwm_pct = -pwm_pct;
    end
    
    pwm_rounded = round(pwm_pct / 10) * 10;
    
    %% 3. จับคู่ลำดับ (Sequential Extraction)
    plot_y = [];
    plot_x_labels = {};
    
    curr_target_idx = 1;
    data_buffer = [];
    
    i = 1;
    while i <= length(pwm_rounded) && curr_target_idx <= length(TARGET_SEQUENCE)
        target = TARGET_SEQUENCE(curr_target_idx);
        current_val = pwm_rounded(i);
        
        if abs(current_val - target) <= TOLERANCE
            data_buffer = [data_buffer; d_spd(i)];
        else
            if ~isempty(data_buffer) && length(data_buffer) > 20
                avg_speed = median(data_buffer);
                
                % *** [แก้ไข] บังคับให้เป็น 0 ถ้า Duty คือ 0 ***
                if target == 0
                    avg_speed = 0;
                end
                
                plot_y(end+1) = avg_speed;
                plot_x_labels{end+1} = num2str(target);
                
                curr_target_idx = curr_target_idx + 1;
                data_buffer = [];
            end
        end
        i = i + 1;
    end
    
    % เก็บตกตัวสุดท้าย (ถ้าจบไฟล์พอดี)
    if ~isempty(data_buffer)
        avg_speed = median(data_buffer);
        
        % *** [แก้ไข] บังคับให้เป็น 0 ถ้า Duty คือ 0 ***
        if TARGET_SEQUENCE(curr_target_idx) == 0
             avg_speed = 0;
        end
        
        plot_y(end+1) = avg_speed;
        plot_x_labels{end+1} = num2str(TARGET_SEQUENCE(curr_target_idx));
    end

    %% 4. พล็อตกราฟ
    figure('Name', 'Unfolded Hysteresis', 'Color', 'w', 'Position', [100, 100, 1000, 600]);
    hold on; grid on; box on;
    
    x_axis = 1:length(plot_y);
    
    % วาดเส้น
    plot(x_axis, plot_y, 'o-', 'LineWidth', 2, 'MarkerSize', 8, ...
         'Color', [0 0.4470 0.7410], 'MarkerFaceColor', 'b');
    
    % ตกแต่ง
    title('Motor Speed Response (0 \rightarrow -100 \rightarrow 0)', 'FontSize', 16);
    xlabel('Duty Cycle (%)', 'FontSize', 14, 'FontWeight', 'bold');
    ylabel('Speed (rad/s)', 'FontSize', 14, 'FontWeight', 'bold');
    
    set(gca, 'XTick', x_axis);
    set(gca, 'XTickLabel', plot_x_labels);
    
    % เส้นแบ่งกึ่งกลาง (-100%)
    mid_idx = find(TARGET_SEQUENCE == -100, 1);
    if ~isempty(mid_idx) && mid_idx <= length(plot_y)
        xline(mid_idx, '--r', 'Max Reverse', 'LineWidth', 1.5, 'LabelVerticalAlignment', 'bottom');
    end
    
    % ปรับแกน Y และ Text
    min_y = min(plot_y);
    max_y = max(plot_y);
    range_y = max_y - min_y;
    ylim([min_y - range_y*0.1, max_y + range_y*0.3]);
    
    % Text
    text_x1 = round(length(plot_y) * 0.25);
    if text_x1 < 1, text_x1 = 1; end
    text(text_x1, max_y + range_y*0.15, 'Forward (0 \rightarrow -100) \rightarrow', ...
         'Color', 'b', 'FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
    
    text_x2 = round(length(plot_y) * 0.75);
    if text_x2 > length(plot_y), text_x2 = length(plot_y); end
    text(text_x2, max_y + range_y*0.15, '\leftarrow Return (-100 \rightarrow 0)', ...
         'Color', 'r', 'FontSize', 12, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');

    fprintf('\nเสร็จสิ้น! บังคับจุด 0%% ให้มีความเร็วเป็น 0 เรียบร้อยครับ\n');

catch ME
    fprintf('ERROR: %s\n', ME.message);
end

%% --- Helper Functions ---
function ds = extract_dataset(loaded_struct)
    names = fieldnames(loaded_struct);
    ds = loaded_struct.(names{1});
end
function sig = find_signal_smart(ds, keywords, type_name)
    all_names = ds.getElementNames();
    for i = 1:length(all_names)
        for k = 1:length(keywords)
            if contains(all_names{i}, keywords{k}, 'IgnoreCase', true)
                sig = ds.getElement(i);
                return;
            end
        end
    end
    try sig = ds.getElement(1); catch, error('Empty Dataset'); end
end