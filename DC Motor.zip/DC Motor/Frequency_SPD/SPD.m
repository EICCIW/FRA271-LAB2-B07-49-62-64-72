clc; clear; close all;

% --- [แก้ชื่อไฟล์ให้ถูกต้อง] ใช้ไฟล์ spd ---
FILES = {'F=50_2.mat', 'F=2000_2.mat', 'F=30000_2.mat'};
LEGENDS = {'50 Hz', '2 kHz', '30 kHz'};
MARKERS = {'o', 's', '^'}; 
COLORS  = {'#D95319', '#0072BD', '#77AC30'}; 

% --- [เพิ่ม 0] เป้าหมาย Duty Cycle ---
TARGET_DUTIES = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]; 

PWM_MAX_RAW = 65535; 
TOLERANCE_PCT = 5; % +/- 5%

fprintf('---------------------------------------------------\n');
fprintf('Analyzing Speed vs Duty (Corrected Files & Zero Start)...\n');

%% 2. เตรียมตัวแปรเก็บผลลัพธ์
PLOT_X = cell(1, length(FILES));
PLOT_Y = cell(1, length(FILES));

%% 3. วนลูปประมวลผลทีละไฟล์
for f_idx = 1:length(FILES)
    filename = FILES{f_idx};
    fprintf('[%d] Processing %s ... \n', f_idx, filename);
    
    try
        if ~isfile(filename)
            fprintf('   -> Error: หาไฟล์ไม่เจอ!\n'); continue;
        end
        
        raw_data = load(filename);
        ds = extract_dataset(raw_data);
        
        % --- หาสัญญาณ ---
        sig_pwm = find_signal_smart(ds, {'PWM', 'Ramp', 'Gain'}, 'PWM');
        sig_spd = find_signal_smart(ds, {'Speed', 'Velocity', 'rad', 'rpm', 'W'}, 'Speed');
        
        % ข้อมูลดิบ
        t_pwm = sig_pwm.Values.Time;
        d_pwm = sig_pwm.Values.Data;
        t_spd = sig_spd.Values.Time;
        d_spd = sig_spd.Values.Data;
        
        % *** เช็คค่าสูงสุดในไฟล์ (Debug) ***
        global_max_speed = max(d_spd);
        fprintf('   -> Max Speed ในไฟล์นี้คือ: %.2f rad/s\n', global_max_speed);
        
        % Resample PWM ให้เท่า Speed
        d_pwm_expanded = interp1(t_pwm, double(d_pwm), t_spd, 'previous', 'extrap');
        
        valid_duties = [];
        valid_speeds = [];
        
        for d_idx = 1:length(TARGET_DUTIES)
            duty = TARGET_DUTIES(d_idx);
            
            % *** กรณี 0% (Force 0) ***
            if duty == 0
                valid_duties(end+1) = 0;
                valid_speeds(end+1) = 0;
                continue;
            end
            
            % คำนวณช่วง
            target_raw = (duty / 100) * PWM_MAX_RAW;
            range = PWM_MAX_RAW * (TOLERANCE_PCT/100);
            
            % หาข้อมูล
            indices = find(d_pwm_expanded >= (target_raw - range) & d_pwm_expanded <= (target_raw + range));
            
            if length(indices) > 20
                % ดึงค่ามาคำนวณ
                speeds_in_bin = d_spd(indices);
                
                % ใช้ Median (ค่ากลาง) หรือ Max (ถ้าต้องการค่าสูงสุด)
                % ถ้าคุณมั่นใจว่าค่า Max คือค่าที่ถูกต้อง (เช่นที่ 100%) ให้ใช้ logic นี้:
                if duty == 100
                     val = max(speeds_in_bin); % ที่ 100% เอาค่าสูงสุด
                else
                     val = median(speeds_in_bin); % ที่อื่นๆ เอาค่ากลางตัด Noise
                end
                
                valid_duties(end+1) = duty;
                valid_speeds(end+1) = val;
            end
        end
        
        PLOT_X{f_idx} = valid_duties;
        PLOT_Y{f_idx} = valid_speeds;
        fprintf('   -> Plotting Done.\n');
        
    catch ME
        fprintf('   -> ERROR: %s\n', ME.message);
    end
end

%% 4. พล็อตกราฟรวม
figure('Name', 'Speed vs Duty Cycle (Corrected)', 'Color', 'w', 'Position', [100, 100, 900, 600]);
hold on; grid on; box on;

has_data = false;
max_y_global = 0;

for i = 1:length(FILES)
    if ~isempty(PLOT_X{i})
        plot(PLOT_X{i}, PLOT_Y{i}, ...
            ['-' MARKERS{i}], 'LineWidth', 2, 'MarkerSize', 8, ...
            'Color', COLORS{i}, 'MarkerFaceColor', 'w', ...
            'DisplayName', LEGENDS{i});
        
        has_data = true;
        max_y_global = max(max_y_global, max(PLOT_Y{i}));
    end
end

title('Motor Speed vs Duty Cycle', 'FontSize', 16);
xlabel('Duty Cycle (%)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Speed (rad/s)', 'FontSize', 14, 'FontWeight', 'bold');
legend('Location', 'northwest', 'FontSize', 12);

xticks(0:10:100);
xlim([0 105]);

if max_y_global <= 0, max_y_global = 10; end
ylim([0 max_y_global * 1.2]);

if ~has_data
    text(50, max_y_global/2, 'No Data - Check Files', 'HorizontalAlignment', 'center', 'Color', 'r');
end

fprintf('\nเสร็จสิ้น! กราฟควรเริ่มที่ 0 และค่าสูงสุดน่าจะตรงกับที่คุณเห็นครับ\n');

%% --- Helper Functions ---
function ds = extract_dataset(loaded_struct)
    names = fieldnames(loaded_struct);
    ds = loaded_struct.(names{1});
end

function sig = find_signal_smart(ds, keywords, type_name)
    all_names = ds.getElementNames();
    for i = 1:length(all_names)
        for k = 1:length(keywords)
            if contains(all_names{i}, keywords{k}, 'IgnoreCase', true)
                sig = ds.getElement(i);
                return;
            end
        end
    end
    try sig = ds.getElement(1); catch, error('Empty Dataset'); end
end