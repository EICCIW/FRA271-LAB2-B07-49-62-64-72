clc; clear; close all;

% ชื่อไฟล์ (แก้ชื่อไฟล์ให้ตรงกับที่คุณมี)
FILES = {'F=50_2.mat', 'F=2000_2.mat', 'F=30000_2.mat'};

% ชื่อที่จะโชว์ในกราฟ
LEGENDS = {'50 Hz (Low)', '2,000 Hz (Medium)', '30,000 Hz (High)'};

% สีและสัญลักษณ์
MARKERS = {'o', 's', '^'}; 
COLORS  = {'#D95319', '#0072BD', '#77AC30'}; % ส้ม, น้ำเงิน, เขียว

% เป้าหมาย Duty Cycle (แกน X)
TARGET_DUTIES = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]; 
PWM_MAX_RAW = 65535; 

fprintf('---------------------------------------------------\n');
fprintf('Analyzing 3 Frequencies (50Hz, 2kHz, 30kHz)...\n');

%% 2. เตรียมตัวแปรเก็บผลลัพธ์
AVG_CURRENTS = zeros(length(FILES), length(TARGET_DUTIES));

%% 3. วนลูปประมวลผลทีละไฟล์
for f_idx = 1:length(FILES)
    filename = FILES{f_idx};
    fprintf('[%d] Processing %s ... ', f_idx, filename);
    
    try
        % 3.1 โหลดข้อมูล
        if ~isfile(filename)
            fprintf(' (หาไฟล์ไม่เจอ! กรุณาเช็คชื่อไฟล์)\n');
            AVG_CURRENTS(f_idx, :) = NaN;
            continue;
        end
        
        raw_data = load(filename);
        ds = extract_dataset(raw_data);
        
        % หาสัญญาณ
        sig_pwm = find_signal_smart(ds, {'PWM', 'Ramp', 'Gain'}, 'PWM');
        sig_curr = find_signal_smart(ds, {'Current', 'mA'}, 'Current');
        
        % ดึงข้อมูล (PWM มีน้อยจุด, Current มีเยอะจุด)
        t_pwm = sig_pwm.Values.Time;
        d_pwm = sig_pwm.Values.Data;
        
        t_curr = sig_curr.Values.Time;
        d_curr = sig_curr.Values.Data;
        
        % *** 3.2 ขยายข้อมูล PWM ให้เท่า Current (Zero-Order Hold) ***
        % ลากเส้นคงที่จากจุดเดิมไปหาจุดใหม่ (ขั้นบันได)
        pwm_resampled = interp1(t_pwm, d_pwm, t_curr, 'previous', 'extrap');
        
        % แปลงเป็น % Duty Cycle (ปัดเศษให้เป็น 0, 10, 20...)
        pwm_pct_stream = round((pwm_resampled / PWM_MAX_RAW) * 100);
        
        % 3.3 วนลูปหาค่าเฉลี่ยแต่ละ Step
        for d_idx = 1:length(TARGET_DUTIES)
            duty_target = TARGET_DUTIES(d_idx);
            
            % หาตำแหน่งที่ PWM (ที่ขยายแล้ว) เท่ากับค่าเป้าหมาย
            indices = find(pwm_pct_stream == duty_target);
            
            if length(indices) > 50 % ต้องมีข้อมูลมากพอสมควร
                % ดึงค่ากระแสในช่วงเวลานั้นมา
                currents_in_step = d_curr(indices);
                
                % ใช้ Median เพื่อตัด Spike และ Noise
                val = median(currents_in_step);
                AVG_CURRENTS(f_idx, d_idx) = val;
            else
                AVG_CURRENTS(f_idx, d_idx) = NaN;
            end
        end
        
        % Auto-Convert to mA (ถ้าค่าน้อยกว่า 10 A)
        if max(AVG_CURRENTS(f_idx, :), [], 'omitnan') < 10
             AVG_CURRENTS(f_idx, :) = AVG_CURRENTS(f_idx, :) * 1000;
             fprintf('(Converted to mA) ');
        end
        fprintf('Done.\n');
        
    catch ME
        fprintf('\n   ERROR: %s\n', ME.message);
    end
end

%% 4. พล็อตกราฟรวม
figure('Name', 'Current vs Duty (3 Frequencies)', 'Color', 'w', 'Position', [100, 100, 900, 600]);
hold on; grid on; box on;

for i = 1:length(FILES)
    % พล็อตเส้น (ข้ามค่า NaN)
    plot(TARGET_DUTIES, AVG_CURRENTS(i, :), ...
        ['-' MARKERS{i}], 'LineWidth', 2, 'MarkerSize', 8, ...
        'Color', COLORS{i}, 'MarkerFaceColor', 'w', ...
        'DisplayName', LEGENDS{i});
end

title('Current vs Duty Cycle at 50Hz, 2kHz, 30kHz', 'FontSize', 16);
xlabel('Duty Cycle (%)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Average Current (mA)', 'FontSize', 14, 'FontWeight', 'bold');
legend('Location', 'northwest', 'FontSize', 12);

xticks(0:10:100);
xlim([0 105]);

% Auto-Zoom Y-Axis
max_val = max(AVG_CURRENTS(:), [], 'omitnan');
if isempty(max_val) || isnan(max_val), max_val = 10; end
ylim([0 max_val * 1.2]);

fprintf('เสร็จสิ้น! กราฟแสดงผล 3 เส้น (50Hz, 2kHz, 30kHz) แล้วครับ\n');

%% --- Helper Functions ---
function ds = extract_dataset(loaded_struct)
    names = fieldnames(loaded_struct);
    ds = loaded_struct.(names{1});
end

function sig = find_signal_smart(ds, keywords, type_name)
    all_names = ds.getElementNames();
    for i = 1:length(all_names)
        for k = 1:length(keywords)
            if contains(all_names{i}, keywords{k}, 'IgnoreCase', true)
                sig = ds.getElement(i);
                return;
            end
        end
    end
    try
        sig = ds.getElement(1);
    catch
        error('No data found');
    end
end