clc; clear; close all;

% จับคู่ไฟล์ (No-Load, Stall, Legend)
FILE_SETS = {
    'F=50No_load2.mat',    'F=50Stall2.mat',    '50 Hz';
    'F=2000No_load2.mat',  'F=2000Stall2.mat',  '2 kHz';
    'F=30000No_load2.mat', 'F=30000Stall2.mat', '30 kHz'
};

COLORS = {'#D95319', '#0072BD', '#77AC30'}; 
MARKERS = {'o', 's', '^'};

% ค่าคงที่
Kt = 0.050535;          
V_SUPPLY_MAX = 12.0;    
PWM_MAX_RAW = 65535;    

% เป้าหมาย Duty Cycle
TARGET_DUTIES = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
TOLERANCE_PCT = 5; 

fprintf('---------------------------------------------------\n');
fprintf('Generating Max Efficiency (Resampling + Edge Fix)...\n');

%% 2. วนลูปคำนวณทีละความถี่
PLOT_X = cell(1, 3);
PLOT_Y = cell(1, 3);

for i = 1:size(FILE_SETS, 1)
    f_nl = FILE_SETS{i, 1};
    f_st = FILE_SETS{i, 2};
    label = FILE_SETS{i, 3};
    
    fprintf('\n[%d] Processing %s ...\n', i, label);
    
    try
        % --- โหลดและ Resample ข้อมูล (เพื่อแก้ปัญหาจุดไม่เท่ากัน) ---
        [ds_nl, sig_pwm_nl, sig_I_nl, sig_W_nl] = load_and_prep(f_nl, {'Current', 'mA'}, {'Speed', 'W', 'rad'});
        [ds_st, sig_pwm_st, sig_I_st, ~]        = load_and_prep(f_st, {'Current', 'mA'}, {});
        
        % ขยาย PWM ให้เท่ากับ Signal (Resampling)
        d_pwm_nl_exp = interp1(sig_pwm_nl.Values.Time, double(sig_pwm_nl.Values.Data), sig_I_nl.Values.Time, 'previous', 'extrap');
        d_pwm_st_exp = interp1(sig_pwm_st.Values.Time, double(sig_pwm_st.Values.Data), sig_I_st.Values.Time, 'previous', 'extrap');
        
        % แปลงหน่วย Current
        d_I_nl = sig_I_nl.Values.Data; if max(d_I_nl) > 10, d_I_nl = d_I_nl/1000; end
        d_W_nl = sig_W_nl.Values.Data;
        d_I_st = sig_I_st.Values.Data; if max(d_I_st) > 10, d_I_st = d_I_st/1000; end
        
        % --- วนลูปคำนวณ ---
        eff_results = [];
        valid_duties = [];
        
        for k = 1:length(TARGET_DUTIES)
            duty = TARGET_DUTIES(k);
            
            % *** FIX 1: บังคับ 0% = 0 ***
            if duty == 0
                valid_duties(end+1) = 0;
                eff_results(end+1) = 0;
                continue;
            end
            
            % คำนวณเป้าหมาย PWM
            target_raw = (duty/100) * PWM_MAX_RAW;
            range = PWM_MAX_RAW * (TOLERANCE_PCT/100);
            
            % 1. หา Inl, Wnl
            idx_nl = find(d_pwm_nl_exp >= (target_raw - range) & d_pwm_nl_exp <= (target_raw + range));
            if isempty(idx_nl)
                val_I_nl = NaN; val_W_nl = NaN;
            else
                val_I_nl = median(d_I_nl(idx_nl));
                val_W_nl = median(d_W_nl(idx_nl));
            end
            
            % 2. หา Ist
            idx_st = find(d_pwm_st_exp >= (target_raw - range) & d_pwm_st_exp <= (target_raw + range));
            if isempty(idx_st)
                val_I_st = NaN;
            else
                val_I_st = median(d_I_st(idx_st));
            end
            
            % *** FIX 2: ถ้าหา 100% ไม่เจอ ให้ใช้ค่า Max ในไฟล์ ***
            if duty == 100 && (isnan(val_I_nl) || isnan(val_I_st) || val_I_nl == 0)
                fprintf('   (Auto-Fix 100%% using Max values) ');
                val_I_nl = max(d_I_nl);
                val_W_nl = max(d_W_nl);
                val_I_st = max(d_I_st);
            end
            
            % ข้ามถ้ายังหาไม่เจอ
            if isnan(val_I_nl) || isnan(val_I_st) || isnan(val_W_nl), continue; end
            
            % --- คำนวณ Eff ---
            I_opt = sqrt(val_I_nl * val_I_st);
            
            T_opt = Kt * (I_opt - val_I_nl);
            denom = (val_I_st - val_I_nl);
            if denom == 0, denom = 1e-6; end
            W_opt = val_W_nl * ((val_I_st - I_opt) / denom);
            
            V_in = V_SUPPLY_MAX * (duty / 100);
            P_in = V_in * I_opt;
            P_out = T_opt * W_opt;
            
            if P_in > 0.0001
                Eff = (P_out / P_in) * 100;
            else
                Eff = 0;
            end
            
            if Eff > 100, Eff = NaN; end
            if Eff < 0, Eff = 0; end
            
            valid_duties(end+1) = duty;
            eff_results(end+1) = Eff;
            
            fprintf('Duty %d%%: Eff=%.2f%%\n', duty, Eff);
        end
        
        PLOT_X{i} = valid_duties;
        PLOT_Y{i} = eff_results;
        
    catch ME
        fprintf('    -> ERROR: %s\n', ME.message);
    end
end

%% 4. พล็อตกราฟ
figure('Name', 'PWM vs Efficiency (Final Fixed)', 'Color', 'w', 'Position', [100, 100, 800, 600]);
hold on; grid on; box on;

for i = 1:size(FILE_SETS, 1)
    if ~isempty(PLOT_X{i})
        plot(PLOT_X{i}, PLOT_Y{i}, ...
            ['-' MARKERS{i}], 'LineWidth', 2, 'MarkerSize', 8, ...
            'Color', COLORS{i}, 'MarkerFaceColor', 'w', ...
            'DisplayName', FILE_SETS{i, 3});
    end
end

title(sprintf('PWM Duty Cycle vs Max Efficiency (Kt=%.4f)', Kt), 'FontSize', 16);
xlabel('PWM Duty Cycle (%)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Efficiency (%)', 'FontSize', 14, 'FontWeight', 'bold');
legend('Location', 'best', 'FontSize', 12);
xlim([0 105]); ylim([0 100]);

fprintf('\nเสร็จสิ้น! กราฟควรจะสมบูรณ์แล้วครับ\n');

%% --- Helper Functions ---
function [ds, sig_pwm, sig_1, sig_2] = load_and_prep(fname, key1, key2)
    if ~isfile(fname), error('File not found'); end
    raw = load(fname);
    if isfield(raw, 'data'), ds = raw.data;
    elseif isfield(raw, 'ans'), ds = raw.ans;
    else, f = fieldnames(raw); ds = raw.(f{1}); end
    
    sig_pwm = find_signal_smart(ds, {'PWM', 'Ramp', 'Gain'});
    sig_1 = find_signal_smart(ds, key1);
    if ~isempty(key2)
        sig_2 = find_signal_smart(ds, key2);
    else
        sig_2 = [];
    end
end

function sig = find_signal_smart(ds, keywords)
    all_names = ds.getElementNames();
    for i = 1:length(all_names)
        for k = 1:length(keywords)
            if contains(all_names{i}, keywords{k}, 'IgnoreCase', true)
                sig = ds.getElement(i);
                return;
            end
        end
    end
    try sig = ds.getElement(1); catch, error('Empty'); end
end