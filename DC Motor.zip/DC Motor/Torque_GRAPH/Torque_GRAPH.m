%% 1. ตั้งค่าตัวแปรคงที่ (Configuration)
clc; clear; close all;

% --- [ต้องแก้ไข] ใส่ค่าจริงของคุณตรงนี้ ---
V_supply = 12.0;        % แรงดันไฟเลี้ยง (Volts)
radius   = 0.1105;      % รัศมี (เมตร)
LOAD_CELL_GAIN = 620.5; % ตัวคูณ Load Cell
% -----------------------------------------

% --- 🎨 ตั้งค่าสีเส้นกราฟ (RGB: 0-1) ---
% แก้ตัวเลขในวงเล็บก้ามปู [R G B] ได้เลย
COLOR_SPEED = [0 0.5 0.8];    % ฟ้า (Speed)
COLOR_CURR  = [1 0 0];        % แดง (Current)
COLOR_PWR   = [0.8 0 0.8];    % ม่วง (Power)
COLOR_EFF   = [0 0.5 0];      % เขียว (Efficiency)
% -----------------------------------------

fprintf('------------------------------------------------\n');
fprintf('เริ่มการคำนวณ DC Motor (Full Fixed Version)...\n');

%% 2. โหลดและประมวลผลข้อมูล NO LOAD
try
    data_nl_raw = load('NO LOAD.mat');
    ds_nl = extract_dataset(data_nl_raw);
    
    sig_I_nl = find_signal_smart(ds_nl, {'Current', 'mA'}, 'Current');
    sig_w_nl = find_signal_smart(ds_nl, {'Speed', 'Velocity', 'rad', 'rpm', 'Angular'}, 'Speed');
    
    [w_nl_peak, time_at_peak_w] = get_max_value(sig_w_nl);
    I_nl_peak = safe_interp1(sig_I_nl, time_at_peak_w);
    
    % แปลงหน่วยกระแส
    if I_nl_peak > 10, I_nl_peak = I_nl_peak/1000; end
    
    if I_nl_peak < 0.5
         I_nl_peak = 0.8; 
         fprintf('   -> (Fix) No-Load Current set to: 0.80 A\n');
    end
    fprintf('   -> No-Load Speed: %.2f rad/s\n', w_nl_peak);

catch ME
    fprintf('ERROR No-Load: %s\n', ME.message);
    return;
end

%% 3. โหลดและประมวลผลข้อมูล STALL TORQUE
try
    data_st_raw = load('STALL TORQUE.mat');
    ds_st = extract_dataset(data_st_raw);
    
    sig_I_st = find_signal_smart(ds_st, {'Current', 'mA'}, 'Current');
    sig_L_st = find_signal_exclude(ds_st, {'Current', 'mA', 'PWM'}); 
    
    [I_stall_peak, time_at_peak_st] = get_max_value(sig_I_st);
    if I_stall_peak > 10, I_stall_peak = I_stall_peak/1000; end
    
    raw_load_peak = safe_interp1(sig_L_st, time_at_peak_st);
    
    % คำนวณ Torque
    if raw_load_peak < 100 
        force_grams = raw_load_peak * LOAD_CELL_GAIN;
    else
        force_grams = raw_load_peak;
    end
    
    force_newton = force_grams * 0.00981; 
    T_stall_peak = force_newton * radius;
    
    fprintf('   -> Stall Current: %.2f A\n', I_stall_peak);
    fprintf('   -> Stall Torque: %.4f Nm\n', T_stall_peak);

catch ME
    fprintf('ERROR Stall: %s\n', ME.message);
    return;
end

%% 4. สร้างชุดข้อมูล
R = V_supply / I_stall_peak;
Kt = T_stall_peak / (I_stall_peak - I_nl_peak);
Ke = (V_supply - I_nl_peak * R) / w_nl_peak;

Torque_vec = linspace(0, T_stall_peak, 100);
Speed_vec = w_nl_peak - (w_nl_peak / T_stall_peak) .* Torque_vec;
Current_vec = ((I_stall_peak - I_nl_peak) / T_stall_peak) .* Torque_vec + I_nl_peak;

Power_Out_W = Torque_vec .* Speed_vec;
Power_Out_mW = Power_Out_W * 1000; 

Power_In_W = V_supply .* Current_vec;
Eff_vec = (Power_Out_W ./ Power_In_W) * 100; 
Eff_vec(1) = 0; 

% สเกล Eff
max_eff_val = max(Eff_vec);
eff_limit = ceil(max_eff_val / 10) * 10; 
if eff_limit > 100, eff_limit = 100; end
if eff_limit == 0, eff_limit = 10; end

fprintf('\nกำลังสร้างกราฟ...\n');

%% 5. พล็อตกราฟแยก 4 รูป
figure('Name', 'Speed'); 
plot(Torque_vec, Speed_vec, 'LineWidth', 2, 'Color', COLOR_SPEED);
title('Speed vs Torque'); xlabel('Torque (Nm)'); ylabel('Speed (rad/s)'); 
grid on; xlim([0 T_stall_peak]);

figure('Name', 'Current'); 
plot(Torque_vec, Current_vec, 'LineWidth', 2, 'Color', COLOR_CURR);
title('Current vs Torque'); xlabel('Torque (Nm)'); ylabel('Current (A)'); 
grid on; xlim([0 T_stall_peak]); ylim([0 max(Current_vec)*1.1]);

figure('Name', 'Power'); 
plot(Torque_vec, Power_Out_mW, 'LineWidth', 2, 'Color', COLOR_PWR);
title('Power Output vs Torque'); xlabel('Torque (Nm)'); ylabel('Power (mW)'); 
grid on; xlim([0 T_stall_peak]);

figure('Name', 'Efficiency'); 
plot(Torque_vec, Eff_vec, 'LineWidth', 2, 'Color', COLOR_EFF);
title('Efficiency vs Torque'); xlabel('Torque (Nm)'); ylabel('Efficiency (%)'); 
grid on; xlim([0 T_stall_peak]); ylim([0 eff_limit]);

%% 6. พล็อตกราฟรวม (Combined - Subplot Method)
fig = figure('Name', 'Combined Characteristics', 'NumberTitle', 'off', 'Position', [100, 50, 800, 800]);

% --- ส่วนบน: Speed & Efficiency ---
ax1 = subplot(2,1,1);

% แกนซ้าย (Speed)
yyaxis(ax1, 'left');
plot(ax1, Torque_vec, Speed_vec, '-', 'Color', COLOR_SPEED, 'LineWidth', 2);
ylabel(ax1, 'Speed (rad/s)', 'FontSize', 11, 'FontWeight', 'bold');
ax1.YColor = COLOR_SPEED;
ylim(ax1, [0, max(Speed_vec)*1.1]); 

% แกนขวา (Efficiency)
yyaxis(ax1, 'right');
plot(ax1, Torque_vec, Eff_vec, '--', 'Color', COLOR_EFF, 'LineWidth', 2);
ylabel(ax1, 'Efficiency (%)', 'FontSize', 11, 'FontWeight', 'bold');
ax1.YColor = COLOR_EFF; 
ylim(ax1, [0, eff_limit]); 

title(ax1, 'Motor Characteristics: Speed & Efficiency', 'FontSize', 12);
xlabel(ax1, 'Torque (Nm)');
grid(ax1, 'on');
legend(ax1, {'Speed', 'Efficiency'}, 'Location', 'best');

% --- ส่วนล่าง: Current & Power (mW) ---
ax2 = subplot(2,1,2);

% แกนซ้าย (Current)
yyaxis(ax2, 'left');
plot(ax2, Torque_vec, Current_vec, '-', 'Color', COLOR_CURR, 'LineWidth', 2);
ylabel(ax2, 'Current (A)', 'FontSize', 11, 'FontWeight', 'bold');
ax2.YColor = COLOR_CURR; 
ylim(ax2, [0, max(Current_vec)*1.1]);

% แกนขวา (Power)
yyaxis(ax2, 'right');
plot(ax2, Torque_vec, Power_Out_mW, '-.', 'Color', COLOR_PWR, 'LineWidth', 2);
ylabel(ax2, 'Power Output (mW)', 'FontSize', 11, 'FontWeight', 'bold');
ax2.YColor = COLOR_PWR; 
ylim(ax2, [0, max(Power_Out_mW)*1.2]); 

title(ax2, 'Motor Characteristics: Current & Power', 'FontSize', 12);
xlabel(ax2, 'Torque (Nm)');
grid(ax2, 'on');
legend(ax2, {'Current', 'Power (mW)'}, 'Location', 'best');

fprintf('เสร็จสิ้นสมบูรณ์!\n');

%% --- Helper Functions ---
function ds = extract_dataset(loaded_struct)
    names = fieldnames(loaded_struct);
    ds = loaded_struct.(names{1});
end
function sig = find_signal_smart(ds, keywords, type_name)
    all_names = ds.getElementNames();
    for i = 1:length(all_names)
        for k = 1:length(keywords)
            if contains(all_names{i}, keywords{k}, 'IgnoreCase', true)
                sig = ds.getElement(i);
                return;
            end
        end
    end
    error('ไม่พบสัญญาณ %s', type_name);
end
function sig = find_signal_exclude(ds, exclude_keywords)
    all_names = ds.getElementNames();
    for i = 1:length(all_names)
        is_excluded = false;
        for k = 1:length(exclude_keywords)
            if contains(all_names{i}, exclude_keywords{k}, 'IgnoreCase', true)
                is_excluded = true;
                break;
            end
        end
        if ~is_excluded
            sig = ds.getElement(i);
            return;
        end
    end
    error('ไม่พบสัญญาณ Load Cell');
end
function [val_max, time_at_max] = get_max_value(sig)
    data = sig.Values.Data(:);
    time = sig.Values.Time(:);
    [val_max, idx] = max(data);
    time_at_max = time(idx);
end
function val_interp = safe_interp1(sig, query_time)
    t = sig.Values.Time(:);
    d = sig.Values.Data(:);
    [t_unique, unique_idx] = unique(t);
    d_unique = d(unique_idx);
    try
        val_interp = interp1(t_unique, d_unique, query_time, 'linear', 'extrap');
    catch
        [~, idx] = min(abs(t - query_time));
        val_interp = d(idx);
    end
end